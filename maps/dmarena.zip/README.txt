Fun little half-life deathmatch map based on a level from nerf arena.

To install simply unzip and copy the bsp file into your half-life/valve "maps" directory