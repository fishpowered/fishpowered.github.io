To install unzip the file at the root of the CS mod directory i.e. so the files in maps/ end up in the maps folder, the files in sound/ end up in the sound/ folder etc.

Created by Matt Pike (Meat Popsicle)