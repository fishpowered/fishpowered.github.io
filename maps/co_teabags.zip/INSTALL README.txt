extract files to your nsp folder 
i.e.
"C:\Program Files\Steam\SteamApps\YourEmailAddy@Domain.com\half-life\nsp"
...and enjoy
Meat.